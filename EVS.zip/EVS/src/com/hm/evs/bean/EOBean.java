package com.hm.evs.bean;

public class EOBean {
	String electoralOfficerID;
	String constituency;

	public String getElectoralOfficerID() {
		return electoralOfficerID;
	}

	public void setElectoralOfficerID(String electoralOfficerID) {
		this.electoralOfficerID = electoralOfficerID;
	}

	public String getConstituency() {
		return constituency;
	}

	public void setConstituency(String constituency) {
		this.constituency = constituency;
	}

}
