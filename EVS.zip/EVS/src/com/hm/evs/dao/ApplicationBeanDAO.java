package com.hm.evs.dao;

import org.springframework.orm.hibernate3.HibernateTemplate;
import com.hm.evs.bean.ApplicationBean;
import java.util.*;

public class ApplicationBeanDAO {
	HibernateTemplate template;

	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}

	public void createApplicationBean(ApplicationBean ab) {
		template.save(ab);
	}

	// method to delete employee
	public void deleteApplicationBean(ApplicationBean ab) {
		template.delete(ab);
	}

	// method to update employee
	public void updateApplicationBean(ApplicationBean ab) {
		template.update(ab);
	}

	// method to return one employee of given id
	public ApplicationBean getById(String id) {
		ApplicationBean ab = (ApplicationBean) template.get(ApplicationBean.class, id);
		return ab;
	}

	// method to return all employees
	public ArrayList<ApplicationBean> findAll() {
		ArrayList<ApplicationBean> list = new ArrayList<ApplicationBean>();
		list = (ArrayList<ApplicationBean>) template.loadAll(ApplicationBean.class);
		return list;
	}
}
