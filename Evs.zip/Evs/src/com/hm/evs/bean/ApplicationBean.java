package com.hm.evs.bean;

public class ApplicationBean {
	String userID;
	String constituency;
	int passedStatus;
	int approvedStatus;
	String voterID;

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getConstituency() {
		return constituency;
	}

	public void setConstituency(String constituency) {
		this.constituency = constituency;
	}

	public int getPassedStatus() {
		return passedStatus;
	}

	public void setPassedStatus(int passedStatus) {
		this.passedStatus = passedStatus;
	}

	public int getApprovedStatus() {
		return approvedStatus;
	}

	public void setApprovedStatus(int approvedStatus) {
		this.approvedStatus = approvedStatus;
	}

	public String getVoterID() {
		return voterID;
	}

	public void setVoterID(String voterID) {
		this.voterID = voterID;
	}

}

