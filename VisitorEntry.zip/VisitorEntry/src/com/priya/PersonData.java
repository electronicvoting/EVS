package com.priya;

public class PersonData {
	private String firstName;
	private int Studentid;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public int getStudentid() {
		return Studentid;
	}

	public void setStudentid(int Studentid) {
		this.Studentid = Studentid;
	}

	/*
	 * @Override public String toString() { return "PersonData ={firstName:'" +
	 * firstName + "', Studentid:'" + Studentid + "'}"; }
	 */

}
