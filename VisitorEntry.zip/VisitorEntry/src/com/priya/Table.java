package com.priya;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Table
 */
@WebServlet("/Table")
public class Table extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Table() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
/*	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}

/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection con=null;
		Statement statement;
		ResultSet resultSet;
		ResultSetMetaData rsmd;
		try{
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();  
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@localhost:1521:XE";
			con=DriverManager.getConnection(url,"hr","hr");
			String table=request.getParameter("sname");
			statement =con.createStatement();
			String query ="SELECT * from "+table;
			out.print("<table width=50% border=1>");  
			resultSet=statement.executeQuery(query);
			rsmd=resultSet.getMetaData();
			int numCount=rsmd.getColumnCount();
			out.print("<tr>");  
			for(int num=0;num<numCount; num++)
			{	
			response.getWriter().append("<th>"+rsmd.getColumnName(num+1)+"</th>");
			}
			out.print("</tr>");  
			System.out.println();
			while(resultSet.next()){
				response.getWriter().append("<tr>");

				for(int j=1;j<=rsmd.getColumnCount();j++){
					

					response.getWriter().append("<td>"+resultSet.getString(j)+"</td>");
				}
				response.getWriter().append("</tr>");
				
				
				//response.getWriter().append("<br>");


			}
			out.print("</table>");  
			//response.getWriter().append("<a href='InsertingValues?tname=" + request.getParameter("tname") + "'>Adding a Row</a></body></html>");
		}
		catch(SQLException e){
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try{

				con.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}
}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	

		